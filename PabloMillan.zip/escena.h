#ifndef _ESCENA_H
#define _ESCENA_H

#include "ejes.h"
#include "malla.h"
#include "cubo.h"
#include "tetraedro.h"
#include "objply.h"
#include "objrevolucion.h"
#include "cilindro.h"
#include "cono.h"
#include "esfera.h"
#include "luz.h"
#include "luzdireccional.h"
#include "luzposicional.h"
#include "material.h"
#include "ovni.h"

typedef enum {NADA, SELOBJETO,SELVISUALIZACION,SELDIBUJADO, MODOALFA, MODOBETA, GRADOSLIBERTAD, SELVELOCIDAD} menu;
class Escena
{

   private:

   bool figuras[2] = {false, false};

 // ** PARÁMETROS DE LA CÁMARA (PROVISIONAL)
       
       // variables que definen la posicion de la camara en coordenadas polares
   GLfloat Observer_distance;
   GLfloat Observer_angle_x;
   GLfloat Observer_angle_y;

   // variables que controlan la ventana y la transformacion de perspectiva
   GLfloat Width, Height, Front_plane, Back_plane;

    // Transformación de cámara
	void change_projection( const float ratio_xy );
	void change_observer();
    


   void clear_window();

   menu modoMenu=NADA;
   // Objetos de la escena
   Ejes ejes;
   std::vector<Malla3D*> objetos;
   std::vector<LuzDireccional> lucesdir;
   std::vector<LuzPosicional> lucespos;
   Cubo * cubo = nullptr ; // es importante inicializarlo a 'nullptr'
   Tetraedro * tetraedro= nullptr ; // es importante inicializarlo a 'nullptr'
   ObjRevolucion * peon = nullptr;
   ObjRevolucion * peon2 = nullptr;
   ObjRevolucion * peon_r = nullptr;
   Cilindro * cil = nullptr;
   Cono * con = nullptr;
   Esfera * esf = nullptr;
   ObjPLY * ply = nullptr;
   Ovni * ovn = nullptr;

   //Control de animaciones

   float v1 = 1, v2 = 1, v3 = 1, v4 = 0;
   float contador1 = 0;
   float contador2 = 0;

   float sentido1 = 1;
   float sentido2 = 1;

   bool animacion_activa = false;
   int id_grado = -1;
   
   public:

    Escena();
	void inicializar( int UI_window_width, int UI_window_height );
	void redimensionar( int newWidth, int newHeight ) ;

	// Dibujar
	void dibujar() ;

	// Interacción con la escena
	bool teclaPulsada( unsigned char Tecla1, int x, int y ) ;
	void teclaEspecial( int Tecla1, int x, int y );

   //void funcion_idle();
   void animarModeloJerarquico();

};
#endif
